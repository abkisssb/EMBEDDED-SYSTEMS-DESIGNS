#ifndef SYSTICK_H
#define SYSTICK_H

void SysTick_Init(unsigned long period);
void SysTick_Handler(void);

#endif
